package lesson2;

public class DemoArrayStack {
	public static void main(String []args) {
		ArrayStack as = new ArrayStack(6);
	    as.menu();
	   
		
		
	}

}
