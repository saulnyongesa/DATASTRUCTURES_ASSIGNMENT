# datastructures
repo to keep track on DS lessons and practice
