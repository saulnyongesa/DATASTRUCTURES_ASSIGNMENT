package cat210;

public interface ScreenSpec
{
    //method defined to get the screen resolution
String getResolution();
    //method defined to get the screen refresh rate
int getRefreshRate();
    //method defined to get the scree response time
int getResponseTime();
}