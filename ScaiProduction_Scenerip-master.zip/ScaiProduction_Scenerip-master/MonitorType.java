package cat210;

public enum MonitorType {
    LCD, LED;
    
}
