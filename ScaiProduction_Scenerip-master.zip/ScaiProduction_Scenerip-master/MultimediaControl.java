package cat210;

public interface MultimediaControl {
    //defining method foir playing 
    public void play();
    //defining method for stop
    public void stop();
    //defining method for previous
    public void previous();
    //defining method for next
    public void next();
    
}
